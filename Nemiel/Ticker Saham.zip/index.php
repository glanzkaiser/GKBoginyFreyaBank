<?php
	include_once('simple_html_dom.php'); 
?>
<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">   
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<style>
@import url(https://fonts.googleapis.com/css?family=Roboto:400,300,600,400italic);
* {
	margin: 0;
	padding: 0;
	box-sizing: border-box;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-font-smoothing: antialiased;
	-moz-font-smoothing: antialiased;
	-o-font-smoothing: antialiased;
	font-smoothing: antialiased;
	text-rendering: optimizeLegibility;
	}

body, table {
	font-family: "Roboto", Helvetica, Arial, sans-serif;
	font-weight: 100;
	font-size: 12px;
	line-height: 30px;
	color: #777;
	background: #4CAF50;
}

.container{
	width:auto;
}

img{
	width:20px;
}

table, th, td{
		background:white;
        border: 1px solid #ccc;
        border-collapse:collapse;
		margin: 0 auto;
}

th{
	text-align:center;
	white-space: nowrap;
}

td{
	text-align:right;
	white-space: nowrap;
}

.tengah{
	text-align: center;
}

.kiri{
	text-align: left;
}


.container {
  display:table;
  margin: 0 auto;
  position: relative;
}

#contact textarea,
#contact input[type="button"],
#contact input[type="submit"] {
  font: 400 12px/16px "Roboto", Helvetica, Arial, sans-serif;
}

#contact {
  background: #F9F9F9;
  padding: 25px 25px 0px 25px;
  margin: 50px 0 50px 0;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}

#contact h3 {
  display: block;
  font-size: 30px;
  font-weight: 300;
  margin-bottom: 10px;
}

fieldset {
  border: medium none !important;
  margin: 0 0 10px;
  min-width: 100%;
  padding: 0;
  width: 100%;
}

#contact textarea {
  width: 100%;
  border: 1px solid #ccc;
  background: #FFF;
  margin: 0 0 5px;
  padding: 10px;
}

#contact textarea {
  max-width: 100%;
  resize: none;
}

#contact input[type="button"],
#contact input[type="submit"] {
  cursor: pointer;
  width: 100%;
  border: none;
  background: #4CAF50;
  color: #FFF;
  margin: 0 0 5px;
  padding: 10px;
  font-size: 15px;
}

#contact input[type="button"]:hover,
#contact input[type="submit"]:hover {
  background: #43A047;
  -webkit-transition: background 0s ease-in-out;
  -moz-transition: background 0s ease-in-out;
  transition: background-color 0s ease-in-out;
}

.copyright {
  text-align: center;
}

#contact input:focus{
	outline: 0;
}
#contact textarea:focus {
  outline: 0;
  border: 1px solid #aaa;
}

::-webkit-input-placeholder {
  color: #888;
}

:-moz-placeholder {
  color: #888;
}

::-moz-placeholder {
  color: #888;
}

:-ms-input-placeholder {
  color: #888;
}
</style>

<body>
<div class="container">  
  <form id="contact" method="post" action="">
    <h3>TICKER Checker</h3>
    <fieldset>
      <textarea name="ticker" placeholder="Type your TICKER here...." rows="10" cols="50" required></textarea>
    </fieldset>
    <fieldset>
      <input name="submit" type="submit" id="contact-submit" value="Submit"/>
    </fieldset>
		<input type="hidden" value="<?php echo '';?>"/>
	<table class="table" id="myTableTicker">
	<?php
		if(isset($_POST['submit'])){
			$ticker = preg_split('/\r\n|[\r\n]/', $_POST['ticker']);
			if(count($ticker)>0){
				echo '<thead><tr><th>TICKER</th><th>Lowest</th><th>Highest</th><th>Current Price</th><th>Value (Today)</th><th>Total Asset</th><th>Debt</th><th>Equity</th><th>Net.Profit</th><th>Market Cap</th><th>Industri</th></tr></thead>';
				foreach($ticker as $ticker){
					if(strlen(trim($ticker))>0){
						$data = get_ticker(strtoupper($ticker));
						echo '<tr><td class="tengah">' . strtoupper($ticker) . '</td><td>' . $data['lowest'] . '</td><td>' . $data['highest'] . '</td><td>' . $data['current'] . '</td><td>' . $data['val_today'] . '</td><td>' . $data['total_asset'] . '</td><td>' . $data['debt'] . '</td><td>' . $data['equity'] . '</td><td>' . $data['net_profit'] . '</td><td>' . $data['market_cap'] . '</td><td class="kiri">' . $data['industri'] . '</td></tr>';
					}
				}
			}
		}
	?>
	</table>
	<p class="copyright">Designed by <a href="https://ekosantoso.com" target="_blank" title="EkoSantoso.com">EkoSantoso.com</a></p>
  </form>
</div>
</body>
<script>
$(document).ready(function(){
    $('#myTableTicker').dataTable();
});
</script>

<?php
	function get_ticker($ticker){
		$ticker = strtoupper(trim($ticker));
		$html = file_get_html('https://indopremier.com/module/saham/include/stockInfo-all-desktop.php?code=' . $ticker);
		$array = array();
		$industri = $html->find('div[id^=stockInfoName]',0);
		$array['industri'] = get_industri($ticker);
		foreach($html->find('table') as $table){
			$tt = array();
			foreach($table->find('tr') as $row){
				$rr = array();
				foreach($row->find('td') as $col){
					if(strlen(trim($col->plaintext))>0){
						$rr[] = $col->plaintext;
					}
				}
				if(count($rr)>1){
					$tt[] = $rr;
				}
			}
			if(count($tt)>1){
				$array[] = $tt;
			}
		}
		// echo '<pre>';
		// print_r($array);
		// echo '</pre>';
		// $response = array("lowest"=>array_key_exists(5,$array)? $array[5][7][4] : 0,
						  // "highest"=>array_key_exists(5,$array)? $array[5][7][2] : 0,
						  // "current"=>array_key_exists(1,$array)? $array[1][0][2] : 0,
						  // "val_today"=>array_key_exists(0,$array)? format_num3($array[0][1][7]) : 0,
						  // "total_asset"=>array_key_exists(4,$array)? format_num3($array[4][4][1]) : 0,
						  // "debt"=>array_key_exists(4,$array)? reformat_num(format_num($array[4][5][1])+format_num($array[4][6][1])) : 0,
						  // "equity"=>array_key_exists(4,$array)? format_num3($array[4][7][1]) : 0,
						  // "net_profit"=>array_key_exists(4,$array)? format_num3($array[4][11][1]) : 0,
						  // "market_cap"=>array_key_exists(4,$array)? format_num3($array[4][2][1]) : 0,
						  // "industri"=>$array['industri']);
		$response = array("lowest"=>array_key_exists(5,$array)? $array[5][7][4] : 0,
						  "highest"=>array_key_exists(5,$array)? $array[5][7][2] : 0,
						  "current"=>array_key_exists(1,$array)? $array[1][0][2] : 0,
						  "val_today"=>array_key_exists(0,$array)? $array[0][1][7] : 0,
						  "total_asset"=>array_key_exists(4,$array)? $array[4][4][1] : 0,
						  "debt"=>array_key_exists(4,$array)? reformat_num2(format_num($array[4][5][1])+format_num($array[4][6][1])) : 0,
						  "equity"=>array_key_exists(4,$array)? $array[4][7][1] : 0,
						  "net_profit"=>array_key_exists(4,$array)? $array[4][11][1] : 0,
						  "market_cap"=>array_key_exists(4,$array)? $array[4][2][1] : 0,
						  "industri"=>$array['industri']);
		// echo json_encode($response);
		return $response;
	}
	
	function format_num($string){
		$string = trim($string);
		if(strpos($string,' T')){
			$num = floatval(str_replace(array(' T',','),'',$string)) * 1000000000000;
		}elseif(strpos($string,' B')){
			$num = floatval(str_replace(array(' B',','),'',$string)) * 1000000000;
		}elseif(strpos($string,' M')){
			$num = floatval(str_replace(array(' M',','),'',$string)) * 1000000;
		}else{
			$num = floatval($string);
		}
			
		return $num;
	}
	
	function reformat_num($num){
		if($num>=1000000000000){
			$num = number_format($num/1000000000000,1);
		}elseif($num>=1000000000){
			$num = number_format($num/1000000000,1);
		}elseif($num>=1000000){
			$num = number_format($num/1000000,1);
		}else{
			$num = number_format($num,1);
		}
		return floatval($num);
	}
	
	function reformat_num2($num){
		if($num>=1000000000000){
			$num = number_format($num/1000000000000,1) . ' T';
		}elseif($num>=1000000000){
			$num = number_format($num/1000000000,1) . ' B';
		}elseif($num>=1000000){
			$num = number_format($num/1000000,1) . ' M';
		}else{
			$num = number_format($num,1);
		}
		return $num;
	}
	
	function format_num3($num){
		$num = str_replace(' T','',$num);
		$num = str_replace(' B','',$num);
		$num = str_replace(',','',$num);
		return floatval($num);
	}
	
	function get_industri($ticker){
		$saham = array('AALI'=>array('Astra Agro Lestari Tbk','AGRI | LQ45 | KOMPAS100'),
						'ABBA'=>array('Mahaka Media Tbk','TRADE'),
						'ABDA'=>array('Asuransi Bina Dana Arta Tbk','FINANCE'),
						'ABMM'=>array('ABM Investama Tbk','TRADE'),
						'ACES'=>array('Ace Hardware Indonesia Tbk','TRADE | KOMPAS100 | PEFINDO25'),
						'ACST'=>array('Acset Indonusa Tbk','PROPERTY | PEFINDO25'),
						'ADES'=>array('Akasha Wira International Tbk','CONSUMER'),
						'ADHI'=>array('Adhi Karya (Persero) Tbk','PROPERTY | LQ45 | KOMPAS100'),
						'ADMF'=>array('Adira Dinamika Multi Finance Tbk','FINANCE'),
						'ADMG'=>array('Polychem Indonesia Tbk','MISC-IND'),
						'ADRO'=>array('Adaro Energy Tbk','MINING | LQ45 | KOMPAS100'),
						'AGRO'=>array('Bank Rakyat Indonesia Agroniaga Tbk','FINANCE'),
						'AGRS'=>array('Bank Agris Tbk.','FINANCE'),
						'AHAP'=>array('Asuransi Harta Aman Pratama Tbk','FINANCE'),
						'AIMS'=>array('Akbar Indo Makmur Stimec Tbk','TRADE'),
						'AISA'=>array('Tiga Pilar Sejahtera Food Tbk.','CONSUMER | KOMPAS100'),
						'AKKU'=>array('Alam Karya Unggul Tbk','BASIC-IND'),
						'AKPI'=>array('Argha Karya Prima Industry Tbk','BASIC-IND'),
						'AKRA'=>array('AKR Corporindo Tbk','TRADE | LQ45 | KOMPAS100'),
						'AKSI'=>array('Majapahit Securities Tbk','FINANCE'),
						'ALDO'=>array('Alkindo Naratama Tbk','BASIC-IND'),
						'ALKA'=>array('Alakasa Industrindo Tbk','BASIC-IND'),
						'ALMI'=>array('Alumindo Light Metal Industry Tbk','BASIC-IND'),
						'ALTO'=>array('Tri Banyan Tirta Tbk','CONSUMER'),
						'AMAG'=>array('Asuransi Multi Artha Guna Tbk','FINANCE'),
						'AMFG'=>array('Asahimas Flat Glass Tbk','BASIC-IND'),
						'AMIN'=>array('Ateliers Mecaniques D Indonesia Tbk.','MISC-IND'),
						'AMRT'=>array('Sumber Alfaria Trijaya Tbk','TRADE'),
						'ANJT'=>array('Austindo Nusantara Jaya Tbk','AGRI'),
						'ANTM'=>array('Aneka Tambang (Persero) Tbk','MINING | LQ45 | KOMPAS100'),
						'APEX'=>array('Apexindo Pratama Duta Tbk','TRADE'),
						'APIC'=>array('Pacific Strategic Financial Tbk','FINANCE'),
						'APII'=>array('Arita Prima Indonesia Tbk','TRADE'),
						'APLI'=>array('Asiaplast Industries Tbk','BASIC-IND'),
						'APLN'=>array('Agung Podomoro Land Tbk','PROPERTY | KOMPAS100'),
						'APOL'=>array('Arpeni Pratama Ocean Line Tbk','INFRASTRUC'),
						'ARGO'=>array('Argo Pantes Tbk','MISC-IND'),
						'ARII'=>array('Atlas Resources Tbk','MINING'),
						'ARNA'=>array('Arwana Citramulia Tbk','BASIC-IND | PEFINDO25'),
						'ARTA'=>array('Arthavest Tbk','FINANCE'),
						'ARTI'=>array('Ratu Prabu Energi Tbk','MINING'),
						'ARTO'=>array('Bank Artos Indonesia Tbk.','FINANCE'),
						'ASBI'=>array('Asuransi Bintang Tbk','FINANCE'),
						'ASDM'=>array('Asuransi Dayin Mitra Tbk','FINANCE'),
						'ASGR'=>array('Astra Graphia Tbk','TRADE'),
						'ASII'=>array('Astra International Tbk','MISC-IND | LQ45 | KOMPAS100'),
						'ASJT'=>array('Asuransi Jasa Tania Tbk','FINANCE'),
						'ASMI'=>array('Asuransi Mitra Maparya Tbk','FINANCE'),
						'ASRI'=>array('Alam Sutera Realty Tbk','PROPERTY | LQ45 | KOMPAS100'),
						'ASRM'=>array('Asuransi Ramayana Tbk','FINANCE'),
						'ASSA'=>array('Adi Sarana Armada Tbk','INFRASTRUC | PEFINDO25'),
						'ATIC'=>array('Anabatic Technologies Tbk.','TRADE'),
						'ATPK'=>array('ATPK Resources Tbk','MINING'),
						'AUTO'=>array('Astra Otoparts Tbk','MISC-IND'),
						'BABP'=>array('Bank ICB Bumiputera Tbk','FINANCE'),
						'BACA'=>array('Bank Capital Indonesia Tbk','FINANCE'),
						'BAJA'=>array('Saranacentral Bajatama Tbk','BASIC-IND'),
						'BALI'=>array('Bali Towerindo Sentra Tbk','INFRASTRUC'),
						'BAPA'=>array('Bekasi Asri Pemula Tbk','PROPERTY'),
						'BATA'=>array('Sepatu Bata Tbk','MISC-IND'),
						'BAYU'=>array('Bayu Buana Tbk','TRADE'),
						'BBCA'=>array('Bank Central Asia Tbk','FINANCE | LQ45 | KOMPAS100'),
						'BBHI'=>array('Bank Harda Internasional Tbk.','FINANCE'),
						'BBKP'=>array('Bank Bukopin Tbk','FINANCE'),
						'BBLD'=>array('Buana Finance Tbk','FINANCE'),
						'BBMD'=>array('Bank Mestika Dharma Tbk','FINANCE'),
						'BBNI'=>array('Bank Negara Indonesia (Persero) Tbk','FINANCE | LQ45 | KOMPAS100'),
						'BBNP'=>array('Bank Nusantara Parahyangan Tbk','FINANCE'),
						'BBRI'=>array('Bank Rakyat Indonesia (Persero) Tbk','FINANCE | LQ45 | KOMPAS100'),
						'BBRM'=>array('Pelayaran Nasional Bina Buana Raya Tbk','INFRASTRUC'),
						'BBTN'=>array('Bank Tabungan Negara (Persero) Tbk','FINANCE | LQ45 | KOMPAS100'),
						'BBYB'=>array('Bank Yudha Bhakti Tbk.','FINANCE'),
						'BCAP'=>array('MNC Kapital Indonesia Tbk','FINANCE'),
						'BCIC'=>array('Bank Mutiara Tbk','FINANCE'),
						'BCIP'=>array('Bumi Citra Permai Tbk','PROPERTY | KOMPAS100'),
						'BDMN'=>array('Bank Danamon Indonesia Tbk','FINANCE | KOMPAS100'),
						'BEKS'=>array('PT BPD Banten','FINANCE'),
						'BEST'=>array('Bekasi Fajar Industrial Estate Tbk','PROPERTY | KOMPAS100 | PEFINDO25'),
						'BFIN'=>array('BFI Finance Indonesia Tbk','FINANCE'),
						'BGTG'=>array('Bank Ganesha Tbk','FINANCE'),
						'BHIT'=>array('MNC Investama Tbk','TRADE | KOMPAS100'),
						'BIKA'=>array('Binakarya Jaya Abadi Tbk','PROPERTY'),
						'BIMA'=>array('Primarindo Asia Infrastructure Tbk','MISC-IND'),
						'BINA'=>array('Bank Ina Perdana Tbk','FINANCE'),
						'BIPI'=>array('Benakat Integra Tbk','MINING'),
						'BIPP'=>array('Bhuwanatala Indah Permai Tbk','PROPERTY'),
						'BIRD'=>array('Blue Bird Tbk.','INFRASTRUC | KOMPAS100'),
						'BISI'=>array('BISI International Tbk','AGRI | PEFINDO25'),
						'BJBR'=>array('Bank Pembangunan Daerah Jawa Barat dan Banten Tbk','FINANCE | KOMPAS100'),
						'BJTM'=>array('Bank Pembangunan Daerah Jawa Timur Tbk','FINANCE | KOMPAS100'),
						'BKDP'=>array('Bukit Darmo Property Tbk','PROPERTY'),
						'BKSL'=>array('Sentul City Tbk','PROPERTY | KOMPAS100'),
						'BKSW'=>array('Bank QNB Kesawan Tbk','FINANCE'),
						'BLTA'=>array('Berlian Laju Tanker Tbk','INFRASTRUC'),
						'BLTZ'=>array('Graha Layar Prima Tbk.','TRADE'),
						'BMAS'=>array('Bank Maspion Indonesia Tbk','FINANCE'),
						'BMRI'=>array('Bank Mandiri (Persero) Tbk','FINANCE | LQ45 | KOMPAS100'),
						'BMSR'=>array('Bintang Mitra Semestaraya Tbk','TRADE'),
						'BMTR'=>array('Global Mediacom Tbk','TRADE | LQ45 | KOMPAS100'),
						'BNBA'=>array('Bank Bumi Arta Tbk','FINANCE'),
						'BNBR'=>array('Bakrie Brothers Tbk','TRADE'),
						'BNGA'=>array('Bank CIMB Niaga Tbk','FINANCE'),
						'BNII'=>array('Bank Internasional Indonesia Tbk','FINANCE'),
						'BNLI'=>array('Bank Permata Tbk','FINANCE'),
						'BOLT'=>array('Garuda Metalindo Tbk','MISC-IND'),
						'BORN'=>array('Borneo Lumbung Energi Metal Tbk','MINING'),
						'BPFI'=>array('Batavia Prosperindo Finance Tbk','FINANCE'),
						'BPII'=>array('Batavia Prosperindo Internasional Tbk.','FINANCE'),
						'BRAM'=>array('Indo Kordsa Tbk','MISC-IND'),
						'BRAU'=>array('Berau Coal Energy Tbk','MINING'),
						'BRMS'=>array('Bumi Resources Minerals Tbk','TRADE'),
						'BRNA'=>array('Berlina Tbk','BASIC-IND'),
						'BRPT'=>array('Barito Pacific Tbk','BASIC-IND'),
						'BSDE'=>array('Bumi Serpong Damai Tbk','PROPERTY | LQ45 | KOMPAS100'),
						'BSIM'=>array('Bank Sinarmas Tbk','FINANCE'),
						'BSSR'=>array('Baramulti Suksessarana Tbk','MINING'),
						'BSWD'=>array('Bank Of India Indonesia Tbk','FINANCE'),
						'BTEK'=>array('Bumi Teknokultura Unggul Tbk','AGRI'),
						'BTEL'=>array('Bakrie Telecom Tbk','INFRASTRUC'),
						'BTON'=>array('Betonjaya Manunggal Tbk','BASIC-IND'),
						'BTPN'=>array('Bank Tabungan Pensiunan Nasional Tbk','FINANCE'),
						'BUDI'=>array('Budi Starch Sweetener Tbk','BASIC-IND'),
						'BUKK'=>array('Bukaka Teknik Utama Tbk','INFRASTRUC'),
						'BULL'=>array('Buana Listya Tama Tbk','INFRASTRUC'),
						'BUMI'=>array('Bumi Resources Tbk','MINING | KOMPAS100'),
						'BUVA'=>array('Bukit Uluwatu Villa Tbk','TRADE'),
						'BVIC'=>array('Bank Victoria International Tbk','FINANCE'),
						'BWPT'=>array('BW Plantation Tbk','AGRI | KOMPAS100'),
						'BYAN'=>array('Bayan Resources Tbk','MINING'),
						'CANI'=>array('Capitol Nusantara Indonesia Tbk','INFRASTRUC'),
						'CASA'=>array('Capital Financial Indonesia Tbk','FINANCE'),
						'CASS'=>array('Cardig Aero Services Tbk','INFRASTRUC'),
						'CEKA'=>array('Wilmar Cahaya Indonesia Tbk','CONSUMER'),
						'CENT'=>array('Centrin Online Tbk','TRADE'),
						'CFIN'=>array('Clipan Finance Indonesia Tbk','FINANCE'),
						'CINT'=>array('Chitose Internasional Tbk.','CONSUMER'),
						'CITA'=>array('Cita Mineral Investindo Tbk','MINING'),
						'CKRA'=>array('Cakra Mineral Tbk','MINING'),
						'CLPI'=>array('Colorpak Indonesia Tbk','TRADE'),
						'CMNP'=>array('Citra Marga Nusaphala Persada Tbk','INFRASTRUC'),
						'CMPP'=>array('Centris Multipersada Pratama Tbk','INFRASTRUC'),
						'CNKO'=>array('Exploitasi Energi Indonesia Tbk','TRADE'),
						'CNTB'=>array('Saham Seri B ( Centex Tbk )','MISC-IND'),
						'CNTX'=>array('Century Textile Industry Tbk','MISC-IND'),
						'COWL'=>array('Cowell Development Tbk','PROPERTY'),
						'CPGT'=>array('Cipaganti Citra Graha Tbk','INFRASTRUC'),
						'CPIN'=>array('Charoen Pokphand Indonesia Tbk','BASIC-IND | LQ45 | KOMPAS100'),
						'CPRO'=>array('Central Proteinaprima Tbk','AGRI | KOMPAS100'),
						'CSAP'=>array('Catur Sentosa Adiprana Tbk','TRADE | PEFINDO25'),
						'CTBN'=>array('Citra Tubindo Tbk','BASIC-IND'),
						'CTRA'=>array('Ciputra Development Tbk','PROPERTY | KOMPAS100'),
						'CTRP'=>array('Ciputra Property Tbk','PROPERTY'),
						'CTRS'=>array('Ciputra Surya Tbk','PROPERTY'),
						'CTTH'=>array('Citatah Tbk','MINING'),
						'DAJK'=>array('Dwi Aneka Jaya Kemasindo Tbk.','BASIC-IND'),
						'DART'=>array('Duta Anggada Realty Tbk','PROPERTY'),
						'DAYA'=>array('Duta Intidaya Tbk','TRADE'),
						'DEFI'=>array('Danasupra Erapacific Tbk','FINANCE'),
						'DEWA'=>array('Darma Henwa Tbk','MINING'),
						'DGIK'=>array('Nusa Konstruksi Enjiniring Tbk','PROPERTY'),
						'DILD'=>array('Intiland Development Tbk','PROPERTY | KOMPAS100'),
						'DKFT'=>array('Central Omega Resources Tbk','MINING'),
						'DLTA'=>array('Delta Djakarta Tbk','CONSUMER'),
						'DMAS'=>array('Puradelta Lestari Tbk','PROPERTY'),
						'DNAR'=>array('Bank Dinar Indonesia Tbk.','FINANCE'),
						'DNET'=>array('Indoritel Makmur Internasional Tbk','TRADE'),
						'DOID'=>array('Delta Dunia Makmur Tbk','MINING'),
						'DPNS'=>array('Duta Pertiwi Nusantara Tbk','BASIC-IND'),
						'DPUM'=>array('Dua Putra Utama Makmur Tbk.','TRADE'),
						'DSFI'=>array('Dharma Samudera Fishing Industries Tbk','AGRI | KOMPAS100'),
						'DSNG'=>array('Dharma Satya Nusantara Tbk','AGRI | KOMPAS100'),
						'DSSA'=>array('Dian Swastatika Sentosa Tbk','TRADE'),
						'DUTI'=>array('Duta Pertiwi Tbk','PROPERTY'),
						'DVLA'=>array('Darya-Varia Laboratoria Tbk','CONSUMER'),
						'DYAN'=>array('Dyandra Media International Tbk','TRADE'),
						'ECII'=>array('Electronic City Indonesia Tbk','TRADE'),
						'EKAD'=>array('Ekadharma International Tbk','BASIC-IND'),
						'ELSA'=>array('Elnusa Tbk','MINING | PEFINDO25 | KOMPAS100'),
						'ELTY'=>array('Bakrieland Development Tbk','PROPERTY'),
						'EMDE'=>array('Megapolitan Developments Tbk','PROPERTY'),
						'EMTK'=>array('Elang Mahkota Teknologi Tbk','TRADE'),
						'ENRG'=>array('Energi Mega Persada Tbk','MINING | KOMPAS100'),
						'EPMT'=>array('Enseval Putera Megatrading Tbk','TRADE'),
						'ERAA'=>array('Erajaya Swasembada Tbk','TRADE | KOMPAS100'),
						'ERTX'=>array('Eratex Djaja Tbk','MISC-IND'),
						'ESSA'=>array('Surya Esa Perkasa Tbk','MINING'),
						'ESTI'=>array('Ever Shine Tex Tbk','MISC-IND'),
						'ETWA'=>array('Eterindo Wahanatama Tbk','BASIC-IND'),
						'EXCL'=>array('XL Axiata Tbk','INFRASTRUC | KOMPAS100'),
						'FAST'=>array('Fast Food Indonesia Tbk','TRADE'),
						'FASW'=>array('Fajar Surya Wisesa Tbk','BASIC-IND'),
						'FISH'=>array('FKS Multi Agro Tbk','TRADE'),
						'FMII'=>array('Fortune Mate Indonesia Tbk','PROPERTY'),
						'FORU'=>array('Fortune Indonesia Tbk','TRADE'),
						'FPNI'=>array('Lotte Chemical Titan Tbk','BASIC-IND'),
						'FREN'=>array('Smartfren Telecom Tbk','INFRASTRUC'),
						'GAMA'=>array('Gading Development Tbk','PROPERTY'),
						'GDST'=>array('Gunawan Dianjaya Steel Tbk','BASIC-IND'),
						'GDYR'=>array('Goodyear Indonesia Tbk','MISC-IND'),
						'GEMA'=>array('Gema Grahasarana Tbk','TRADE'),
						'GEMS'=>array('Golden Energy Mines Tbk','MINING'),
						'GGRM'=>array('Gudang Garam Tbk','CONSUMER | LQ45 | KOMPAS100'),
						'GIAA'=>array('Garuda Indonesia (Persero) Tbk','INFRASTRUC | KOMPAS100'),
						'GJTL'=>array('Gajah Tunggal Tbk','MISC-IND | KOMPAS100'),
						'GLOB'=>array('Global Teleshop Tbk','TRADE'),
						'GMCW'=>array('Grahamas Citrawisata Tbk','TRADE'),
						'GMTD'=>array('Gowa Makassar Tourism Development Tbk','PROPERTY'),
						'GOLD'=>array('Golden Retailindo Tbk','TRADE'),
						'GOLL'=>array('Golden Plantation Tbk.','AGRI'),
						'GPRA'=>array('Perdana Gapuraprima Tbk','PROPERTY'),
						'GREN'=>array('Evergreen Invesco Tbk','TRADE'),
						'GSMF'=>array('Equity Development Investment Tbk','FINANCE'),
						'GTBO'=>array('Garda Tujuh Buana Tbk','MINING'),
						'GWSA'=>array('Greenwood Sejahtera Tbk','PROPERTY'),
						'GZCO'=>array('Gozco Plantations Tbk','AGRI'),
						'HADE'=>array('HD Capital Tbk','FINANCE'),
						'HDFA'=>array('HD Finance Tbk','FINANCE'),
						'HDTX'=>array('Panasia Indo Resources Tbk','MISC-IND'),
						'HERO'=>array('Hero Supermarket Tbk','TRADE'),
						'HEXA'=>array('Hexindo Adiperkasa Tbk','TRADE'),
						'HITS'=>array('Humpuss Intermoda Transportasi Tbk','INFRASTRUC'),
						'HMSP'=>array('HM Sampoerna Tbk','CONSUMER | LQ45 | KOMPAS100'),
						'HOME'=>array('Hotel Mandarine Regency Tbk','TRADE'),
						'HOTL'=>array('Saraswati Griya Lestari Tbk','TRADE'),
						'HRUM'=>array('Harum Energy Tbk','MINING'),
						'IATA'=>array('Indonesia Air Transport Tbk','INFRASTRUC'),
						'IBFN'=>array('Intan Baruprana Finance Tbk.','FINANCE'),
						'IBST'=>array('Inti Bangun Sejahtera Tbk','INFRASTRUC'),
						'ICBP'=>array('Indofood CBP Sukses Makmur Tbk','CONSUMER | LQ45 | KOMPAS100'),
						'ICON'=>array('Island Concepts Indonesia Tbk','TRADE'),
						'IDPR'=>array('Indonesia Pondasi Raya Tbk.','PROPERTY'),
						'IGAR'=>array('Champion Pacific Indonesia Tbk','BASIC-IND'),
						'IIKP'=>array('Inti Agri Resources Tbk','AGRI'),
						'IKAI'=>array('Intikeramik Alamasri Industri Tbk','BASIC-IND'),
						'IKBI'=>array('Sumi Indo Kabel Tbk','MISC-IND'),
						'IMAS'=>array('Indomobil Sukses Internasional Tbk','MISC-IND'),
						'IMJS'=>array('Indomobil Multi Jasa Tbk','FINANCE'),
						'IMPC'=>array('Impack Pratama Industri Tbk.','BASIC-IND'),
						'INAF'=>array('Indofarma Tbk','CONSUMER'),
						'INAI'=>array('Indal Aluminium Industry Tbk','BASIC-IND'),
						'INCI'=>array('Intanwijaya Internasional Tbk','BASIC-IND'),
						'INCO'=>array('Vale Indonesia Tbk','MINING | LQ45 | KOMPAS100'),
						'INDF'=>array('Indofood Sukses Makmur Tbk','CONSUMER | LQ45 | KOMPAS100'),
						'INDR'=>array('Indo-Rama Synthetics Tbk','MISC-IND'),
						'INDS'=>array('Indospring Tbk','MISC-IND'),
						'INDX'=>array('Tanah Laut Tbk','INFRASTRUC'),
						'INDY'=>array('Indika Energy Tbk','INFRASTRUC'),
						'INKP'=>array('Indah Kiat Pulp Paper Tbk','BASIC-IND'),
						'INPC'=>array('Bank Artha Graha Internasional Tbk','FINANCE'),
						'INPP'=>array('Indonesian Paradise Property Tbk','TRADE'),
						'INRU'=>array('Toba Pulp Lestari Tbk','BASIC-IND'),
						'INTA'=>array('Intraco Penta Tbk','TRADE'),
						'INTD'=>array('Inter Delta Tbk','TRADE'),
						'INTP'=>array('Indocement Tunggal Prakasa Tbk','BASIC-IND | LQ45 | KOMPAS100'),
						'INVS'=>array('Inovisi Infracom Tbk','INFRASTRUC'),
						'IPOL'=>array('Indopoly Swakarsa Industry Tbk','BASIC-IND'),
						'ISAT'=>array('Indosat Tbk','INFRASTRUC | KOMPAS100'),
						'ISSP'=>array('Steel Pipe Industry of Indonesia Tbk','BASIC-IND'),
						'ITMA'=>array('Sumber Energi Andalan Tbk','TRADE'),
						'ITMG'=>array('Indo Tambangraya Megah Tbk','MINING | KOMPAS100'),
						'ITTG'=>array('Leo Investments Tbk','TRADE'),
						'JAWA'=>array('Jaya Agra Wattie Tbk','AGRI'),
						'JECC'=>array('Jembo Cable Company Tbk','MISC-IND'),
						'JGLE'=>array('Graha Andrasentra Propertindo Tbk','TRADE'),
						'JIHD'=>array('Jakarta International Hotels Development Tbk','TRADE'),
						'JKON'=>array('Jaya Konstruksi Manggala Pratama Tbk','TRADE'),
						'JKSW'=>array('Jakarta Kyoei Steel Works Tbk','BASIC-IND'),
						'JPFA'=>array('Japfa Comfeed Indonesia Tbk','BASIC-IND | KOMPAS100'),
						'JPRS'=>array('Jaya Pari Steel Tbk','BASIC-IND'),
						'JRPT'=>array('Jaya Real Property Tbk','PROPERTY'),
						'JSMR'=>array('Jasa Marga (Persero) Tbk','INFRASTRUC | LQ45 | KOMPAS100'),
						'JSPT'=>array('Jakarta Setiabudi Internasional Tbk','TRADE'),
						'JTPE'=>array('Jasuindo Tiga Perkasa Tbk','TRADE'),
						'KAEF'=>array('Kimia Farma Tbk','CONSUMER'),
						'KARW'=>array('ICTSI Jasa Prima Tbk','INFRASTRUC'),
						'KBLI'=>array('KMI Wire Cable Tbk','MISC-IND'),
						'KBLM'=>array('Kabelindo Murni Tbk','MISC-IND'),
						'KBLV'=>array('First Media Tbk','TRADE'),
						'KBRI'=>array('Kertas Basuki Rachmat Indonesia Tbk','BASIC-IND'),
						'KDSI'=>array('Kedawung Setia Industrial Tbk','CONSUMER'),
						'KIAS'=>array('Keramika Indonesia Assosiasi Tbk','BASIC-IND'),
						'KICI'=>array('Kedaung Indah Can Tbk','CONSUMER'),
						'KIJA'=>array('Kawasan Industri Jababeka Tbk','PROPERTY | KOMPAS100'),
						'KINO'=>array('Kino Indonesia Tbk','CONSUMER'),
						'KKGI'=>array('Resource Alam Indonesia Tbk','MINING'),
						'KLBF'=>array('Kalbe Farma Tbk','CONSUMER | LQ45 | KOMPAS100'),
						'KOBX'=>array('Kobexindo Tractors Tbk','TRADE'),
						'KOIN'=>array('Kokoh Inti Arebama Tbk','TRADE'),
						'KONI'=>array('Perdana Bangun Pusaka Tbk','TRADE'),
						'KOPI'=>array('Mitra Energi Persada Tbk.','INFRASTRUC'),
						'KPIG'=>array('MNC Land Tbk','PROPERTY'),
						'KRAH'=>array('Grand Kartech Tbk','MISC-IND'),
						'KRAS'=>array('Krakatau Steel (Persero) Tbk','BASIC-IND'),
						'KREN'=>array('Kresna Graha Sekurindo Tbk','FINANCE | KOMPAS100'),
						'LAMI'=>array('Lamicitra Nusantara Tbk','PROPERTY'),
						'LAPD'=>array('Leyand International Tbk','INFRASTRUC'),
						'LCGP'=>array('Eureka Prima Jakarta Tbk','PROPERTY | KOMPAS100'),
						'LEAD'=>array('Logindo Samudramakmur Tbk','INFRASTRUC'),
						'LINK'=>array('Link Net Tbk.','TRADE | KOMPAS100 | PEFINDO25'),
						'LION'=>array('Lion Metal Works Tbk','BASIC-IND'),
						'LMAS'=>array('Limas Centric Indonesia Tbk','TRADE'),
						'LMPI'=>array('Langgeng Makmur Industri Tbk','CONSUMER'),
						'LMSH'=>array('Lionmesh Prima Tbk','BASIC-IND'),
						'LPCK'=>array('Lippo Cikarang Tbk','PROPERTY | KOMPAS100 | PEFINDO25'),
						'LPGI'=>array('Lippo General Insurance Tbk','FINANCE'),
						'LPIN'=>array('Multi Prima Sejahtera Tbk','MISC-IND'),
						'LPKR'=>array('Lippo Karawaci Tbk','PROPERTY | LQ45 | KOMPAS100'),
						'LPLI'=>array('Star Pacific Tbk','TRADE'),
						'LPPF'=>array('Matahari Department Store Tbk','TRADE | LQ45 | KOMPAS100 | PEFINDO25'),
						'LPPS'=>array('Lippo Securities Tbk','FINANCE'),
						'LRNA'=>array('Eka Sari Lorena Transport Tbk.','INFRASTRUC'),
						'LSIP'=>array('PP London Sumatra Indonesia Tbk','AGRI | LQ45 | KOMPAS100'),
						'LTLS'=>array('Lautan Luas Tbk','TRADE'),
						'MAGP'=>array('Multi Agro Gemilang Plantation Tbk','AGRI'),
						'MAIN'=>array('Malindo Feedmill Tbk','BASIC-IND'),
						'MAMI'=>array('Mas Murni Indonesia Tbk','TRADE'),
						'MAMIP'=>array('Mas Murni Tbk (Saham Preferen)','TRADE'),
						'MAPI'=>array('Mitra Adiperkasa Tbk','TRADE | KOMPAS100'),
						'MARI'=>array('Mahaka Radio Integra Tbk.','TRADE'),
						'MASA'=>array('Multistrada Arah Sarana Tbk','MISC-IND'),
						'MAYA'=>array('Bank Mayapada Internasional Tbk','FINANCE'),
						'MBAP'=>array('Mitrabara Adiperdana Tbk.','MINING'),
						'MBSS'=>array('Mitrabahtera Segara Sejati Tbk','INFRASTRUC'),
						'MBTO'=>array('Martina Berto Tbk','CONSUMER'),
						'MCOR'=>array('Bank Windu Kentjana International Tbk','FINANCE'),
						'MDIA'=>array('Intermedia Capital Tbk.','TRADE'),
						'MDKA'=>array('Merdeka Copper Gold Tbk.','MINING'),
						'MDLN'=>array('Modernland Realty Ltd Tbk','PROPERTY | KOMPAS100'),
						'MDRN'=>array('Modern Internasional Tbk','TRADE'),
						'MEDC'=>array('Medco Energi International Tbk','MINING'),
						'MEGA'=>array('Bank Mega Tbk','FINANCE'),
						'MERK'=>array('Merck Tbk','CONSUMER'),
						'META'=>array('Nusantara Infrastructure Tbk','INFRASTRUC | KOMPAS100'),
						'MFIN'=>array('Mandala Multifinance Tbk','FINANCE'),
						'MFMI'=>array('Multifiling Mitra Indonesia Tbk','TRADE'),
						'MGNA'=>array('Magna Finance Tbk.','FINANCE'),
						'MICE'=>array('Multi Indocitra Tbk','TRADE'),
						'MIDI'=>array('Midi Utama Indonesia Tbk','TRADE'),
						'MIKA'=>array('Mitra Keluarga Karyasehat Tbk','TRADE | KOMPAS100 | PEFINDO25'),
						'MIRA'=>array('Mitra International Resources Tbk','INFRASTRUC'),
						'MITI'=>array('Mitra Investindo Tbk','MINING'),
						'MKNT'=>array('Mitra Komunikasi Nusantara','INFRASTRUC'),
						'MKPI'=>array('Metropolitan Kentjana Tbk','PROPERTY'),
						'MLBI'=>array('Multi Bintang Indonesia Tbk','CONSUMER'),
						'MLIA'=>array('Mulia Industrindo Tbk','BASIC-IND'),
						'MLPL'=>array('Multipolar Tbk','TRADE | KOMPAS100'),
						'MLPT'=>array('Multipolar Technology Tbk','TRADE'),
						'MMLP'=>array('Mega Manunggal Property Tbk.','PROPERTY'),
						'MNCN'=>array('Media Nusantara Citra Tbk','TRADE | LQ45 | KOMPAS100'),
						'MPMX'=>array('Mitra Pinasthika Mustika Tbk','TRADE'),
						'MPPA'=>array('Matahari Putra Prima Tbk','TRADE | LQ45 | KOMPAS100'),
						'MRAT'=>array('Mustika Ratu Tbk','CONSUMER'),
						'MREI'=>array('Maskapai Reasuransi Indonesia Tbk','FINANCE'),
						'MSKY'=>array('MNC Sky Vision Tbk','TRADE'),
						'MTDL'=>array('Metrodata Electronics Tbk','TRADE | PEFINDO25'),
						'MTFN'=>array('Capitalinc Investment Tbk','FINANCE'),
						'MTLA'=>array('Metropolitan Land Tbk','PROPERTY'),
						'MTRA'=>array('Mitra Pemuda Tbk.','PROPERTY'),
						'MTSM'=>array('Metro Realty Tbk','PROPERTY'),
						'MYOH'=>array('Samindo Resources Tbk','MINING'),
						'MYOR'=>array('Mayora Indah Tbk','CONSUMER'),
						'MYRX'=>array('Hanson International Tbk','TRADE | KOMPAS100 | LQ45'),
						'MYRXP'=>array('Saham Seri B Hanson International Tbk','TRADE'),
						'MYTX'=>array('Apac Citra Centertex Tbk','MISC-IND'),
						'NAGA'=>array('Bank Mitraniaga Tbk','FINANCE'),
						'NELY'=>array('Pelayaran Nelly Dwi Putri Tbk','INFRASTRUC'),
						'NIKL'=>array('Pelat Timah Nusantara Tbk','BASIC-IND'),
						'NIPS'=>array('Nipress Tbk','MISC-IND'),
						'NIRO'=>array('Nirvana Development Tbk','PROPERTY | KOMPAS100'),
						'NISP'=>array('Bank OCBC NISP Tbk','FINANCE'),
						'NOBU'=>array('Bank Nationalnobu Tbk','FINANCE'),
						'NRCA'=>array('Nusa Raya Cipta Tbk','PROPERTY | PEFINDO25'),
						'OASA'=>array('Protech Mitra Perkasa Tbk','INFRASTRUC'),
						'OCAP'=>array('Onix Capital Tbk','FINANCE'),
						'OKAS'=>array('Ancora Indonesia Resources Tbk','TRADE'),
						'OMRE'=>array('Indonesia Prima Property Tbk','PROPERTY'),
						'PADI'=>array('Minna Padi Investama Tbk','FINANCE'),
						'PALM'=>array('Provident Agro Tbk','AGRI'),
						'PANR'=>array('Panorama Sentrawisata Tbk','TRADE'),
						'PANS'=>array('Panin Sekuritas Tbk','FINANCE'),
						'PBRX'=>array('Pan Brothers Tbk','MISC-IND | KOMPAS100'),
						'PDES'=>array('Destinasi Tirta Nusantara Tbk','TRADE'),
						'PEGE'=>array('Panca Global Securities Tbk','FINANCE'),
						'PGAS'=>array('Perusahaan Gas Negara (Persero) Tbk','INFRASTRUC | LQ45 | KOMPAS100'),
						'PGLI'=>array('Pembangunan Graha Lestari Indah Tbk','TRADE'),
						'PICO'=>array('Pelangi Indah Canindo Tbk','BASIC-IND'),
						'PJAA'=>array('Pembangunan Jaya Ancol Tbk','TRADE'),
						'PKPK'=>array('Perdana Karya Perkasa Tbk','MINING'),
						'PLAS'=>array('Polaris Investama Tbk','TRADE | KOMPAS100'),
						'PLIN'=>array('Plaza Indonesia Realty Tbk','PROPERTY'),
						'PNBN'=>array('Bank Pan Indonesia Tbk','FINANCE | KOMPAS100'),
						'PNBS'=>array('Bank Panin Syariah Tbk','FINANCE'),
						'PNIN'=>array('Panin Insurance Tbk','FINANCE'),
						'PNLF'=>array('Panin Financial Tbk','FINANCE | KOMPAS100'),
						'PNSE'=>array('Pudjiadi Sons Tbk','TRADE'),
						'POLY'=>array('Asia Pacific Fibers Tbk','MISC-IND'),
						'POOL'=>array('Pool Advista Indonesia Tbk','TRADE'),
						'POWR'=>array('Cikarang Listrindo Tbk','INFRASTRUC'),
						'PPRO'=>array('PP Property Tbk.','PROPERTY'),
						'PRAS'=>array('Prima Alloy Steel Universal Tbk','MISC-IND'),
						'PSAB'=>array('J Resources Asia Pasifik Tbk','TRADE'),
						'PSDN'=>array('Prasidha Aneka Niaga Tbk','CONSUMER'),
						'PSKT'=>array('Pusako Tarinka Tbk','TRADE'),
						'PTBA'=>array('Tambang Batubara Bukit Asam (Persero) Tbk','MINING | LQ45 | KOMPAS100'),
						'PTIS'=>array('Indo Straits Tbk','INFRASTRUC'),
						'PTPP'=>array('PP (Persero) Tbk','PROPERTY | LQ45 | KOMPAS100'),
						'PTRO'=>array('Petrosea Tbk','MINING'),
						'PTSN'=>array('Sat Nusapersada Tbk','MISC-IND'),
						'PTSP'=>array('Pioneerindo Gourmet International Tbk','TRADE'),
						'PUDP'=>array('Pudjiadi Prestige Tbk','TRADE'),
						'PWON'=>array('Pakuwon Jati Tbk','PROPERTY | LQ45 | KOMPAS100'),
						'PYFA'=>array('Pyridam Farma Tbk','CONSUMER'),
						'RAJA'=>array('Rukun Raharja Tbk','INFRASTRUC | PEFINDO25'),
						'RALS'=>array('Ramayana Lestari Sentosa Tbk','TRADE | KOMPAS100 | PEFINDO25'),
						'RANC'=>array('Supra Boga Lestari Tbk','TRADE'),
						'RBMS'=>array('Ristia Bintang Mahkotasejati Tbk','PROPERTY'),
						'RDTX'=>array('Roda Vivatex Tbk','PROPERTY'),
						'RELI'=>array('Reliance Securities Tbk','FINANCE'),
						'RICY'=>array('Ricky Putra Globalindo Tbk','MISC-IND'),
						'RIGS'=>array('Rig Tenders Indonesia Tbk','INFRASTRUC'),
						'RIMO'=>array('Rimo Catur Lestari Tbk','TRADE'),
						'RMBA'=>array('Bentoel Internasional Investama Tbk','CONSUMER'),
						'RODA'=>array('Pikko Land Development Tbk','PROPERTY'),
						'ROTI'=>array('Nippon Indosari Corpindo Tbk','CONSUMER | PEFINDO25'),
						'RUIS'=>array('Radiant Utama Interinsco Tbk','MINING'),
						'SAFE'=>array('Steady Safe Tbk','INFRASTRUC'),
						'SAME'=>array('Sarana Meditama Metropolitan Tbk','TRADE | PEFINDO25'),
						'SCBD'=>array('Danayasa Arthatama Tbk','PROPERTY'),
						'SCCO'=>array('Supreme Cable Manufacturing Commerce Tbk','MISC-IND'),
						'SCMA'=>array('Surya Citra Media Tbk','TRADE | LQ45 | KOMPAS100 | PEFINDO25'),
						'SCPI'=>array('Merck Sharp Dohme Pharma Tbk','CONSUMER'),
						'SDMU'=>array('Sidomulyo Selaras Tbk','INFRASTRUC'),
						'SDPC'=>array('Millennium Pharmacon International Tbk','TRADE'),
						'SDRA'=>array('Bank Himpunan Saudara Tbk','FINANCE'),
						'SGRO'=>array('Sampoerna Agro Tbk','AGRI'),
						'SHID'=>array('Hotel Sahid Jaya International Tbk','TRADE'),
						'SHIP'=>array('Sillo Maritime Perdana Tbk','INFRASTRUC'),
						'SIAP'=>array('Sekawan Intipratama Tbk','BASIC-IND'),
						'SIDO'=>array('Industri Jamu dan Farmasi Sido Muncul Tbk','CONSUMER | PEFINDO25 | KOMPAS100'),
						'SILO'=>array('Siloam International Hospitals Tbk','TRADE | LQ45 | KOMPAS100 | PEFINDO25'),
						'SIMA'=>array('Siwani Makmur Tbk','BASIC-IND'),
						'SIMP'=>array('Salim Ivomas Pratama Tbk','AGRI | KOMPAS100'),
						'SIPD'=>array('Sierad Produce Tbk','BASIC-IND'),
						'SKBM'=>array('Sekar Bumi Tbk','CONSUMER'),
						'SKLT'=>array('Sekar Laut Tbk','CONSUMER'),
						'SKYB'=>array('Skybee Tbk','TRADE'),
						'SMAR'=>array('Smart Tbk','AGRI'),
						'SMBR'=>array('Semen Baturaja (Persero) Tbk','BASIC-IND | PEFINDO25'),
						'SMCB'=>array('Holcim Indonesia Tbk','BASIC-IND | KOMPAS100'),
						'SMDM'=>array('Suryamas Dutamakmur Tbk','PROPERTY'),
						'SMDR'=>array('Samudera Indonesia Tbk','INFRASTRUC'),
						'SMGR'=>array('Semen Indonesia (Persero) Tbk','BASIC-IND | LQ45 | KOMPAS100'),
						'SMMA'=>array('Sinarmas Multiartha Tbk','FINANCE'),
						'SMMT'=>array('Golden Eagle Energy Tbk','MINING'),
						'SMRA'=>array('Summarecon Agung Tbk','PROPERTY | LQ45 | KOMPAS100'),
						'SMRU'=>array('SMR Utama Tbk','MINING | KOMPAS100'),
						'SMSM'=>array('Selamat Sempurna Tbk','MISC-IND | PEFINDO25'),
						'SOBI'=>array('Sorini Agro Asia Corporindo Tbk','BASIC-IND'),
						'SOCI'=>array('Soechi Lines Tbk.','INFRASTRUC | KOMPAS100'),
						'SONA'=>array('Sona Topas Tourism Industry Tbk','TRADE'),
						'SPMA'=>array('Suparma Tbk','BASIC-IND'),
						'SQBB'=>array('Taisho Pharmaceutical Indonesia Tbk','CONSUMER'),
						'SQBI'=>array('Taisho Pharmaceutical Indonesia Tbk','CONSUMER'),
						'SQMI'=>array('Renuka Coalindo Tbk','TRADE'),
						'SRAJ'=>array('Sejahteraraya Anugrahjaya Tbk','TRADE'),
						'SRIL'=>array('Sri Rejeki Isman Tbk','MISC-IND | KOMPAS100 | LQ45'),
						'SRSN'=>array('Indo Acidatama Tbk','BASIC-IND'),
						'SRTG'=>array('Saratoga Investama Sedaya Tbk','TRADE'),
						'SSIA'=>array('Surya Semesta Internusa Tbk','PROPERTY | KOMPAS100'),
						'SSMS'=>array('Sawit Sumbermas Sarana Tbk','AGRI | LQ45 | KOMPAS100'),
						'SSTM'=>array('Sunson Textile Manufacture Tbk','MISC-IND'),
						'STAR'=>array('Star Petrochem Tbk','MISC-IND'),
						'STTP'=>array('Siantar Top Tbk','CONSUMER'),
						'SUGI'=>array('Sugih Energy Tbk','TRADE | KOMPAS100'),
						'SULI'=>array('SLJ Global Tbk','BASIC-IND'),
						'SUPR'=>array('Solusi Tunas Pratama Tbk','INFRASTRUC'),
						'TALF'=>array('Tunas Alfin Tbk','BASIC-IND'),
						'TARA'=>array('Sitara Propertindo Tbk.','PROPERTY | KOMPAS100'),
						'TAXI'=>array('Express Transindo Utama Tbk','INFRASTRUC'),
						'TBIG'=>array('Tower Bersama Infrastructure Tbk','INFRASTRUC | LQ45 | KOMPAS100'),
						'TBLA'=>array('Tunas Baru Lampung Tbk','AGRI'),
						'TBMS'=>array('Tembaga Mulia Semanan Tbk','BASIC-IND'),
						'TCID'=>array('Mandom Indonesia Tbk','CONSUMER'),
						'TELE'=>array('Tiphone Mobile Indonesia Tbk','TRADE'),
						'TFCO'=>array('Tifico Fiber Indonesia Tbk','MISC-IND'),
						'TGKA'=>array('Tigaraksa Satria Tbk','TRADE'),
						'TIFA'=>array('Tifa Finance Tbk','FINANCE'),
						'TINS'=>array('Timah (Persero) Tbk','MINING | KOMPAS100'),
						'TIRA'=>array('Tira Austenite Tbk','TRADE'),
						'TIRT'=>array('Tirta Mahakam Resources Tbk','BASIC-IND'),
						'TKGA'=>array('Permata Prima Sakti Tbk','TRADE'),
						'TKIM'=>array('Pabrik Kertas Tjiwi Kimia Tbk','BASIC-IND'),
						'TLKM'=>array('Telekomunikasi Indonesia (Persero) Tbk','INFRASTRUC | LQ45 | KOMPAS100'),
						'TMAS'=>array('Pelayaran Tempuran Emas Tbk','INFRASTRUC'),
						'TMPI'=>array('Sigmagold Inti Perkasa Tbk','TRADE'),
						'TMPO'=>array('Tempo Intimedia Tbk','TRADE'),
						'TOBA'=>array('Toba Bara Sejahtra Tbk','MINING'),
						'TOTL'=>array('Total Bangun Persada Tbk','PROPERTY | PEFINDO25'),
						'TOTO'=>array('Surya Toto Indonesia Tbk','BASIC-IND'),
						'TOWR'=>array('Sarana Menara Nusantara Tbk','INFRASTRUC'),
						'TPIA'=>array('Chandra Asri Petrochemical Tbk','BASIC-IND'),
						'TPMA'=>array('Trans Power Marine Tbk','INFRASTRUC'),
						'TRAM'=>array('Trada Maritime Tbk','INFRASTRUC | KOMPAS100'),
						'TRIL'=>array('Triwira Insanlestari Tbk','TRADE'),
						'TRIM'=>array('Trimegah Securities Tbk','FINANCE'),
						'TRIO'=>array('Trikomsel Oke Tbk','TRADE'),
						'TRIS'=>array('Trisula International Tbk','MISC-IND'),
						'TRST'=>array('Trias Sentosa Tbk','BASIC-IND'),
						'TRUB'=>array('Truba Alam Manunggal Engineering Tbk','INFRASTRUC'),
						'TRUS'=>array('Trust Finance Indonesia Tbk','FINANCE'),
						'TSPC'=>array('Tempo Scan Pacific Tbk','CONSUMER'),
						'TURI'=>array('Tunas Ridean Tbk','TRADE'),
						'ULTJ'=>array('Ultra Jaya Milk Industry Trading Company Tbk','CONSUMER'),
						'UNIC'=>array('Unggul Indah Cahaya Tbk','BASIC-IND'),
						'UNIT'=>array('Nusantara Inti Corpora Tbk','MISC-IND'),
						'UNSP'=>array('Bakrie Sumatra Plantations Tbk','AGRI'),
						'UNTR'=>array('United Tractors Tbk','TRADE | LQ45 | KOMPAS100'),
						'UNVR'=>array('Unilever Indonesia Tbk','CONSUMER | LQ45 | KOMPAS100'),
						'VICO'=>array('Victoria Investama Tbk','FINANCE'),
						'VINS'=>array('Victoria Insurance Tbk','FINANCE'),
						'VIVA'=>array('Visi Media Asia Tbk','TRADE | KOMPAS100'),
						'VOKS'=>array('Voksel Electric Tbk','MISC-IND'),
						'VRNA'=>array('Verena Multi Finance Tbk','FINANCE'),
						'WAPO'=>array('Wahana Pronatural Tbk','TRADE'),
						'WEHA'=>array('Panorama Transportasi Tbk','INFRASTRUC'),
						'WICO'=>array('Wicaksana Overseas International Tbk','TRADE'),
						'WIIM'=>array('Wismilak Inti Makmur Tbk','CONSUMER'),
						'WIKA'=>array('Wijaya Karya (Persero) Tbk','PROPERTY | LQ45 | KOMPAS100'),
						'WINS'=>array('Wintermar Offshore Marine Tbk','INFRASTRUC'),
						'WOMF'=>array('Wahana Ottomitra Multiartha Tbk','FINANCE'),
						'WSBP'=>array('PT Waskita Beton Precast Tbk','BASIC-IND'),
						'WSKT'=>array('Waskita Karya (Persero) Tbk','PROPERTY | LQ45 | KOMPAS100'),
						'WTON'=>array('Wijaya Karya Beton Tbk.','BASIC-IND | KOMPAS100 | PEFINDO25'),
						'YPAS'=>array('Yanaprima Hastapersada Tbk','BASIC-IND'),
						'YULE'=>array('Yulie Sekurindo Tbk','FINANCE'),
						'ZBRA'=>array('Zebra Nusantara Tbk','INFRASTRUC')
				);
		return $saham[$ticker][1];
	}
?>