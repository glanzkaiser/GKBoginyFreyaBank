<?php include_once('function.php'); ?>
<?php
	header('Content-Type: text/event-stream');
	header('Cache-Control: no-cache'); 

	$daftar_industri = array("AGRI", "BASIC-IND", "CONSUMER", "FINANCE", "INFRASTRUCT", "MINING", "MISC-IND", "PROPERTY", "TRADE");

	$id = 1;
	$n = 600;
	$list_industri = array();

	foreach($daftar_industri as $di) {
		$url = "http://www.idx.co.id/umbraco/Surface/StockData/GetSecuritiesStock?sector=$di&length=$n";

		$data = file_get_contents($url); 
		$saham = json_decode($data); 
		$daftar_saham = $saham->data;

		foreach ($daftar_saham as $v) {
			$list_industri["$v->Code"] = $di;

			$encodedString = json_encode($list_industri);
			file_put_contents('data/tmp_industri.json', $encodedString);

			$msg = "Stock Code {$v->Code} di industri $di";
			send_message($id++,$msg); 
			sleep(1);
		}
	}

	ksort($list_industri);
	
	$encodedString = json_encode($list_industri);
	file_put_contents('data/list_industri.json', $encodedString);

	$id -= 1;
	echo "Selesai update data sebanyak $id" . PHP_EOL;
	



