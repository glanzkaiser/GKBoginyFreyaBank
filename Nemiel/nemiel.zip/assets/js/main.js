$(document).ready(function() {
    var table = $('#list-saham').DataTable({
        "ajax": "data/list_saham.json",
        "deferRender": true,
        "scrollX": true,
        "columns": [
            { "data": "code" },
            { "data": "stock_name" },
            { "data": "close" },
            { "data": "volume"  },
            { "data": "value" },
            { "data": "low_price" },
            { "data": "high_price" },
            { "data": "share_out" },
            { "data": "equity" },
            { "data": "debt_s" },
            { "data": "debt_l" },
            { "data": "eps"  },
            { "data": "per"  },
            { "data": "bvps" },
            { "data": "pbv"  },
            { "data": "der"  },
            { "data": "net_profit_anlz" },
            { "data": "current" },
            { "data": "net_profit_yt1" },
            { "data": "industri" },
            { "data": "is_undervalued" }
        ],
        "columnDefs": [
            {
                "targets": [20],
                "visible": false,
                "searchable": true
            }
        ]
    });

    $.fn.dataTable.ext.search.push(
        function (settings, data, dataIndex) {
            var sector = $('#sector-list').val();
            var sector_col = data[19] || 0; 

            if (sector == sector_col || sector == "all") {
                return true;
            }
            return false;
        }
    );

    $.fn.dataTable.ext.search.push(
        function (settings, data, dataIndex) {
            var undervalued = $('input[name=undervalued_filter]:checked').val();
            var undervalued_col = data[20] || 0; 

            if (undervalued == undervalued_col || undervalued == "all") {
                return true;
            }
            return false;
        }
    );

    $('#sector-list').on('change', function () {
        table.draw();
    });

    $('input[name=undervalued_filter]').on('change', function () {
        table.draw();
    });

    var buttons = new $.fn.dataTable.Buttons(table, {
        buttons: [
            { extend: 'excel', className: 'btn-primary' },
            { extend: 'csv', className: 'btn-primary' },
            { extend: 'print', className: 'btn-primary' },
            { extend: 'pdf', className: 'btn-primary',orientation: 'landscape', pageSize: 'A2' }
        ]
    }).container().appendTo($('#data-buttons'));

});
