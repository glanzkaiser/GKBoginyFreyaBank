<?php
	include_once('simple_html_dom.php');

	function get_data($code) {
		$stream_opts = [
			"ssl" => [
					"verify_peer"=>false,
					"verify_peer_name"=>false,
			]
		];  
		$html = file_get_html("https://indopremier.com/module/saham/include/stockInfo-all-desktop.php?code=$code", false, stream_context_create($stream_opts));

		$fundamental = $array = get_table($html,'.table-fundamental');
		$orderbook = get_table($html,'.table-orderbook');
		$statistic = get_table($html,'.table-statistic');
	
		// print_r($fundamental);
		// print_r($orderbook);
		// print_r($statistic);

		$list_industri_json = file_get_contents('data/list_industri.json');
		$decoded_list_industri = json_decode($list_industri_json, true);
		$list_industri = $decoded_list_industri;		

		$industri 			= $list_industri[$code];
		$close					= array_key_exists(0,$orderbook)? $orderbook[0][0][1] : 0;
		$bvps  					= array_key_exists(0,$fundamental)? $fundamental[0][16][1] : 0;
		$is_undervalued = is_undervalued($close, $bvps);
		$data 					= array(
					"share_out"=>array_key_exists(0,$fundamental)? $fundamental[0][1][1] : 0,
					"equity"=>array_key_exists(0,$fundamental)? $fundamental[0][7][1] : 0,
					"debt_s"=>array_key_exists(0,$fundamental)? $fundamental[0][5][1] : 0,
					"debt_l"=>array_key_exists(0,$fundamental)? $fundamental[0][6][1] : 0,
					"eps"=>array_key_exists(0,$fundamental)? $fundamental[0][14][1] : 0,
					"per"=>array_key_exists(0,$fundamental)? $fundamental[0][15][1] : 0,
					"bvps"=>$bvps,
					"pbv"=>array_key_exists(0,$fundamental)? $fundamental[0][17][1] : 0,
					"der"=>array_key_exists(0,$fundamental)? $fundamental[0][21][1] : 0,
					"net_profit_anlz"=>array_key_exists(0,$fundamental)? $fundamental[0][11][1] : 0,
					"current"=>array_key_exists(0,$fundamental)? $fundamental[0][11][2] : 0,
					"net_profit_yt1"=>array_key_exists(0,$fundamental)? $fundamental[0][11][3] : 0,
					"close"=>$close,
					"volume"=>array_key_exists(0,$orderbook)? $orderbook[0][0][7] : 0,
					"value"=>array_key_exists(0,$orderbook)? $orderbook[0][1][7] : 0,
					"low_price"=>array_key_exists(0,$statistic)? $statistic[0][7][4] : 0,
					"high_price"=>array_key_exists(0,$statistic)? $statistic[0][7][2] : 0,
					"is_undervalued"=> $is_undervalued,
					"industri"=> $industri,
		);

		return $data;
	}

	function is_undervalued($close, $bvps) {
		$c = str_replace(',', '', $close);
		$b = str_replace(',', '', $bvps);
		$close = (double) trim($c);
		$bvps = (double) trim($b);
		return ($close < $bvps ) ? true : false;
	}

	function get_table($html, $table) {
		$array = array();
		
		foreach($html->find($table) as $table){
			$tt = array();
			foreach($table->find('tr') as $row){
				$rr = array();
				foreach($row->find('td') as $col){
					if(strlen(trim($col->plaintext))>0){
						$rr[] = $col->plaintext;
					}
				}
				if(count($rr)>1){
					$tt[] = $rr;
				}
			}
			if(count($tt)>1){
				$array[] = $tt;
			}
		} 
		return $array;
	}

	function send_message($id, $data) {
		echo "id: $id" . PHP_EOL;
		echo "data: " . json_encode($data) . PHP_EOL;
		echo PHP_EOL;
			
		ob_flush();
		flush();
	}

	function list_saham_tgl() {
		date_default_timezone_set("Asia/Jakarta");
		$filename = 'data/list_saham.json';
		if (file_exists($filename)) {
				return "Update Terakhir : " . date ("d F Y H:i:s", filemtime($filename));
		}
	}