<?php header('Access-Control-Allow-Origin: *'); ?>
<?php include_once('function.php'); ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nemiel</title>
  <link rel="shortcut icon" href="assets/img/icon.png" />
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,700">
  <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
  <link rel="stylesheet" href="assets/css/Footer-Clean.css">
  <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
  <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
  <link rel="stylesheet" href="assets/css/styles.css">
  <link rel="stylesheet" href="assets/DataTables/datatables.min.css">
  <link rel="stylesheet" href="assets/css/buttons.bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
  <div>
    <nav class="navbar navbar-default navigation-clean-button" style="background-color:#003466;" id="navbar-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <a href="#" class="navbar-brand" style="/*height:100px;*//*position:absolute;*/top:63;position:relative;width:160px;">
            <img src="assets/img/header.png" class="hidden-xs hidden-sm" style="position:absolute;top:initial;left:40px;position:absolute;top:initial;*/  top:0;z-index:9999999;width:125px;height:auto;"
            />
          </a>
          <button data-toggle="collapse" data-target="#navcol-1" class="navbar-toggle collapsed">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div class="collapse navbar-collapse" id="navcol-1">
          <ul class="nav navbar-nav">
            <li role="presentation">
              <a href="#">Home </a>
            </li>
            <li role="presentation">
              <a href="#">News </a>
            </li>
            <li role="presentation">
              <a href="#">Social Media</a>
            </li>
            <li role="presentation">
              <a href="#">Infographics </a>
            </li>
            <li role="presentation">
              <a href="#">Spatial News</a>
            </li>
            <li role="presentation">
              <a href="#">Stocks </a>
            </li>
          </ul>
          <div class="hidden-md hidden-lg show-xs show-sm" id="navcol-1">
            <ul class="nav navbar-nav">
              <li role="presentation">
                <a href="#">IDX </a>
              </li>
              <li role="presentation">
                <a href="#">NASDAQ </a>
              </li>
              <li role="presentation">
                <a href="#">NYSE </a>
              </li>
              <li role="presentation">
                <a href="#">SHANGHAI </a>
              </li>
              <li role="presentation">
                <a href="#">EURONEXT </a>
              </li>
              <li role="presentation">
                <a href="#">LONDON </a>
              </li>
              <li role="presentation">
                <a href="#">HONG KONG</a>
              </li>
              <li role="presentation">
                <a href="#">SHENZHEN </a>
              </li>
              <li role="presentation">
                <a href="#">SINGAPORE </a>
              </li>
              <li role="presentation">
                <a href="#">THAILAND </a>
              </li>
            </ul>
            <p class="navbar-text navbar-right actions">
              <a href="#" class="navbar-link login">News for Millenials </a>
            </p>
          </div>
          <ul class="nav navbar-nav navbar-right">
            <li role="presentation">
              <a href="#" class="navbar-link login">Sign In</a>
            </li>
            <li role="presentation">
              <a href="#" class="navbar-link login">
                <i class="glyphicon glyphicon-search"></i>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <nav class="navbar navbar-default hidden-xs hidden-sm navigation-clean-button">
      <div class="container-fluid">
        <div class="navbar-header">
          <a href="#" class="navbar-brand" style="width:160px;"> </a>
          <button data-toggle="collapse" data-target="#navcol-1" class="navbar-toggle collapsed">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div class="collapse navbar-collapse" id="navcol-1">
          <ul class="nav navbar-nav">
            <li role="presentation">
              <a href="#">IDX </a>
            </li>
            <li role="presentation">
              <a href="#">NASDAQ </a>
            </li>
            <li role="presentation">
              <a href="#">NYSE </a>
            </li>
            <li role="presentation">
              <a href="#">SHANGHAI </a>
            </li>
            <li role="presentation">
              <a href="#">EURONEXT </a>
            </li>
            <li role="presentation">
              <a href="#">LONDON </a>
            </li>
            <li role="presentation">
              <a href="#">HONG KONG</a>
            </li>
            <li role="presentation">
              <a href="#">SHENZHEN </a>
            </li>
            <li role="presentation">
              <a href="#">SINGAPORE </a>
            </li>
            <li role="presentation">
              <a href="#">THAILAND </a>
            </li>
          </ul>
          <p class="navbar-text navbar-right actions">
            <a href="#" class="navbar-link login">News for Millenials </a>
          </p>
        </div>
      </div>
    </nav>
  </div>

  <div style="margin:0px;margin-top:30px;">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="panel panel-default">
            <div class="panel-body">
              <div class="form-group col-md-3">
                <select class="form-control" name="sector" id="sector-list">
                  <option value="all">Select Industry / Sector</option>
                  <option value="AGRI">Agriculture</option>
                  <option value="BASIC-IND">Basic Industry and Chemicals</option>
                  <option value="CONSUMER">Consumer Goods Industry</option>
                  <option value="FINANCE">Finance</option>
                  <option value="INFRASTRUCT">Infrastructure, Utilities and Transaportation</option>
                  <option value="MINING">Mining</option>
                  <option value="MISC-IND">Miscellaneous Industry</option>
                  <option value="PROPERTY">Property, Real Estate and Building Construction</option>
                  <option value="TRADE">Trade, Service, and Invesment</option>
                </select>
              </div>
              <div class="form-group col-md-9">
                <label class="radio-inline">
                  <input type="radio" name="undervalued_filter" value="all" checked> All Stocks
                </label>
                <label class="radio-inline">
                  <input type="radio" name="undervalued_filter" value="true"> Undervalued Stocks
                </label>
                <div class="pull-right">
                  <i>
                    <?php echo list_saham_tgl(); ?>
                  </i>
                  <br>
                  <a href="process.php" class="btn btn-info pull-right" target="_blank" onclick="return confirm('Scrap data terbaru membutuhkan beberapa waktu ? Lakukan Update ?')"
                    ;>Update</a>

                </div>
              </div>
              <div class="col-md-12">
                <div id="data-buttons"></div>
              </div>
            </div>
          </div>
          <div class="table-responsive">
            <table id="list-saham" class="table table-striped table-bordered " cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>Stock Code</th>
                  <th>Stock Name</th>
                  <th>Close</th>
                  <th>Volume</th>
                  <th>Value</th>
                  <th>LOWEST PRICE</th>
                  <th>HIGHEST PRICE</th>
                  <th>SHARE OUT</th>
                  <th>EQUITY</th>
                  <th>DEBT SHORT TERM</th>
                  <th>DEBT LONG TERM</th>
                  <th>EPS</th>
                  <th>PER</th>
                  <th>BVPS</th>
                  <th>PBV</th>
                  <th>DER</th>
                  <th>NET PROFIT ANLZ</th>
                  <th>NET PROFIT Qn Yt</th>
                  <th>NET PROFIT Qn Yt-1</th>
                  <th>INDUSTRI</th>
                  <th>Is Undervalued</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>StockCode</th>
                  <th>StockName</th>
                  <th>Close</th>
                  <th>Volume</th>
                  <th>Value</th>
                  <th>LOWEST PRICE</th>
                  <th>HIGHEST PRICE</th>
                  <th>SHARE OUT</th>
                  <th>EQUITY</th>
                  <th>DEBT SHORT TERM</th>
                  <th>DEBT LONG TERM</th>
                  <th>EPS</th>
                  <th>PER</th>
                  <th>BVPS</th>
                  <th>PBV</th>
                  <th>DER</th>
                  <th>NET PROFIT ANLZ</th>
                  <th>NET PROFIT Qn Yt</th>
                  <th>NET PROFIT Qn Yt-1</th>
                  <th>INDUSTRI</th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="footer-clean" style="background-color:#003466;">
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-1 item">
            <h3>
              <img class="img-responsive" src="assets/img/icon.png">
            </h3>
          </div>
          <div class="col-md-7 item">
            <ul class="list-inline">
              <li>
                <a href="#">Terms of Use</a>
              </li>
              <li>
                <a href="#">Privacy Policy</a>
              </li>
              <li>
                <a href="#">Closed Captioning Policy</a>
              </li>
              <li>
                <a href="#">Help </a>
              </li>
            </ul>
            <p class="copyright" style="color:#ffa8f6;">
              <strong>© 2017 Nemiel, LLC. All rights reserved. All market data delayed 20 minutes.</strong>
            </p>
          </div>
          <div class="col-md-4 item social" style="padding-right:0;padding-left:0;">
            <a href="#">
              <i class="fa fa-facebook"></i>
            </a>
            <a href="#">
              <i class="fa fa-twitter"></i>
            </a>
            <a href="#">
              <i class="fa fa-google-plus"></i>
            </a>
            <a href="#">
              <i class="fa fa-instagram"></i>
            </a>
            <a href="#">
              <i class="fa fa-rss"></i>
            </a>
            <a href="#">
              <i class="fa fa-envelope-o"></i>
            </a>
          </div>
        </div>
      </div>
    </footer>
  </div>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/DataTables/datatables.js"></script>
  <script src="assets/DataTables/DataTables-1.10.16/js/dataTables.bootstrap.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.bootstrap.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
  <script src="assets/js/main.js"></script>
</body>

</html>