<?php include_once('function.php'); ?>
<?php
	header('Content-Type: text/event-stream');
	header('Cache-Control: no-cache'); 

	//scrap data nama dan kode stock
	$id = 1;
	$n = 600;
	$url = "http://www.idx.co.id/umbraco/Surface/TradingSummary/GetStockSummary?length=$n"; 
	$data = file_get_contents($url); 
	$saham = json_decode($data); 
	$banyak_data = $saham->recordsTotal;
	$daftar_saham = $saham->data;
	$list_saham = array();

	// echo json_encode($daftar_saham);
	echo "Sedang mengupdate $banyak_data data" . PHP_EOL . PHP_EOL;
	foreach ($daftar_saham as $v) {
		$code = $v->StockCode;
		$data = get_data($code);
		extract($data);
		$row = array(
						"code" => $code,
						"stock_name" => $v->StockName,
						"close" => $close,
						"volume" => $volume, 
						"value" => $value, 
						"low_price" => $low_price, 
						"high_price" => $high_price,
						"equity" => $equity, 
						"share_out" => $share_out, 
						"debt_s" => $debt_s,
						"debt_l" => $debt_l, 
						"eps" => $eps,
						"per" => $per,
						"bvps" => $bvps,
						"pbv" => $pbv, 
						"der" => $der, 
						"net_profit_anlz" => $net_profit_anlz, 
						"current" => $current,
						"net_profit_yt1" => $net_profit_yt1,
						"industri" => $industri,
						"is_undervalued" => $is_undervalued
					);
		array_push($list_saham, $row);

		$saham_tmp = fopen("data/tmp.json", "w") or die("Unable to open file!");
		$txt = json_encode(array("data" => $list_saham));
		fwrite($saham_tmp, $txt);
		fclose($saham_tmp);

    send_message($id++,$row); 
    sleep(1);
}
	//kosongkan tmp
	$saham_tmp = fopen("data/tmp.json", "w") or die("Unable to open file!");
	fwrite($saham_tmp, "");
	fclose($saham_tmp);

	//tulis file asli
	$saham_file = fopen("data/list_saham.json", "w") or die("Unable to open file!");
	$txt = json_encode(array("data" => $list_saham));
	fwrite($saham_file, $txt);
	fclose($saham_file);

	$id -= 1;
	echo "Selesai update data sebanyak $id" . PHP_EOL;

	// print_r($list_saham);

	
